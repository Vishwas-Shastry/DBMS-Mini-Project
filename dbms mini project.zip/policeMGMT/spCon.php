<?php
$servername="localhost";
$username="root";
$password="";
$database_name="policemgmt";

$mysqli = new mysqli("$servername", "$username", "$password", "$database_name");

if ($mysqli->connect_errno) {
    echo "Failed to connect to MariaDB: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}


$stmt = $mysqli->prepare("CALL `deleteClosedCaseFromOpenCase`();");

$stmt->execute();

$stmt->close();

$mysqli->close();
?>




