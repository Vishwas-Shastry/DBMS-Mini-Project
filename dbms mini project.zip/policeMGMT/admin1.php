<?php
$servername="localhost";
$username="root";
$password="";
$database_name="policemgmt";

$conn=mysqli_connect($servername,$username,$password,$database_name);

if(!$conn)
{
    die("Connection Failed:" . mysqli_error());
}
if(isset($_POST['VerifyP']))
{
    echo "test";
    $admin_password=$_POST['password'];
    //echo $user_password;
    $s = " select * from admin_cred where admin_pwd = '$admin_password';";
        
    $result = mysqli_query($conn, $s);

    $num= mysqli_num_rows($result);

    if ($num >0 ){
        
        header("Location: http://localhost/policeMGMT/admin_regester.php");
        
    }
    else {
        echo "User ID/password doesn't match";
        echo "<br>";
        echo "<a href='http://localhost/policeMGMT/home_page.php'>Home</a>";
    }
    mysqli_close($conn);
}

elseif(isset($_POST['VerifyC']))
{
    echo "test";
    $admin_password=$_POST['password'];
    //echo $user_password;
    $s = " select * from admin_cred where admin_pwd = '$admin_password';";
        
    $result = mysqli_query($conn, $s);

    $num= mysqli_num_rows($result);

    if ($num >0 ){
        
        header("Location: http://localhost/policeMGMT/caseIPform.php");
        
    }
    else {
        echo "u are not the admin";
        echo "<br>";
        echo "<a href='http://localhost/policeMGMT/home_page.php'>Home</a>";
    }
    mysqli_close($connec);
}

elseif(isset($_POST['DeleteP']))
{
    echo "test";
    $admin_password=$_POST['password'];
    //echo $user_password;
    $s = " select * from admin_cred where admin_pwd = '$admin_password';";
        
    $result = mysqli_query($conn, $s);

    $num= mysqli_num_rows($result);

    if ($num >0 ){
        
        header("Location: http://localhost/policeMGMT/deleteInfo.php");
        
    }
    else {
        echo "u are not the admin";
        echo "<br>";
        echo "<a href='http://localhost/policeMGMT/home_page.php'>Home</a>";
    }
    mysqli_close($connec);
}

elseif(isset($_POST['VerifyCO']))
{
    echo "test";
    $admin_password=$_POST['password'];
    //echo $user_password;
    $s = " select * from admin_cred where admin_pwd = '$admin_password';";
        
    $result = mysqli_query($conn, $s);

    $num= mysqli_num_rows($result);

    if ($num >0 ){
        
        header("Location: http://localhost/policeMGMT/closedcaseIP.php");
        
    }
    else {
        echo "u are not the admin";
        echo "<br>";
        echo "<a href='http://localhost/policeMGMT/home_page.php'>Home</a>";
    }
    mysqli_close($connec);
}    

?>