
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="dbms proj.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<title>Police Station Management System</title>
</head>
<body background = "POLICE_line.jpg"; background-size 100% 100%>
	<div class="banner">
		<div class="navbar">
			<img src = "http://localhost/policeMGMT/Bangalore_City_Police_Logo.png" class = "logo">
				<ul>
                <li><a href='http://localhost/policeMGMT/home_page.php#'>Home</a></li>
					<li><a href='http://localhost/policeMGMT/select_home.php'>View</a></li>
					<li><a href='http://localhost/policeMGMT/insert_home.php'>Add</a></li>
					<li><a href='http://localhost/policeMGMT/sp_home.php'>Optimize</a></li>
					<li><a href='http://localhost/policeMGMT/delete_dome.php'>Delete</a></li>
					<li><a href='http://localhost/policeMGMT/login11.php'>Logout</a></li>
				</ul>	
		</div>
		<div class="content">
            <button type ="button"><span></span><a href = "http://localhost/policeMGMT/admin_varification.php">Delete Police Info</a></button>
		</div>
	</div>
</body>
</html>

