
<!DOCTYPE html>
<!-- Coding By CodeWithNepal - codewithnepal.com -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body style="background-image: url('http://localhost/policeMGMT/POLICE.jpg'); background-size: cover;">  
    <div class="wrapper">
        <header style="color: whitesmoke;">Sign In</header>
        <form action="login1.php" method = "post">
            <div class="field email">
            <div class="input-area">
           <input type="text" name = 'uname' placeholder="Username">
          <!--<i class="icon fas fa-envelope"></i>
          <i class="error error-icon fas fa-exclamation-circle"></i>-->
        </div>
        <div class="error error-txt">Email can't be blank</div>
      </div>
      <div class="field password">
        <div class="input-area">
          <input type="password" name = 'password' placeholder="Password">
          <!--<i class="icon fas fa-lock"></i>
          <i class="error error-icon fas fa-exclamation-circle"></i>-->
        </div>
        <div class="error error-txt">Password can't be blank</div>
      </div>
      <br>
      <br>
      <button type = "submit" name = "submit" width="75%">
        <span style="position: relative; display: inline-flex;font-weight: bold;">
        Login
        </span>
      </button>
    </form>
    <!-- <div class="sign-txt">Not yet member? <a href="#">Signup now</a></div> -->
  </div>

  <!-- <script src="script.js"></script> -->

</body>
</html>

