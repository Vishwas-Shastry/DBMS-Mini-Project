<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officer details</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body background = "http://localhost/policeMGMT/diamondplate-background.jpg"; background-size 100% 100% >
    <center>
    <div class="wrapper_login">
        <div class="container">
            <div class="col-right">
                <div class="login-form">
                    <h2 style="color:white;">Insert values</h2>
                    <form action="del.php" method="post">
                        <p style="color:white;"> <label style="text-align: left;">Officer ID</label>&nbsp;<input type="text" name="OfficerID" placeholder="Officer id" required></p>
                        <button style="color: black;" type="submit" name="Delete">Delete</button>
                    </form>
                </div>
            </div>
        </div> 
    </div>
</center>
</body>
</html>