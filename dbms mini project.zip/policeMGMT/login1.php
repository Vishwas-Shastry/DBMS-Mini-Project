<?php
$servername="localhost";
$username="root";
$password="";
$database_name="policemgmt";

$conn=mysqli_connect($servername,$username,$password,$database_name);

if(!$conn)
{
    die("Connection Failed:" . mysqli_error());
}
if(isset($_POST['submit']))
{
    echo "test";
    $user_name=$_POST['uname'];
    //echo $user_name;
    $user_password=$_POST['password'];
    //echo $user_password;
    $s = " select * from login_cred where uname = '$user_name' and password = '$user_password';";
        
    $result = mysqli_query($conn, $s);

    $num= mysqli_num_rows($result);

    if ($num >0 ){
        
        header("Location: http://localhost/policeMGMT/home_page.php");
        
    }
    else {
        echo "User ID/password doesn't match";
        echo "<br>";
        echo "<a href='http://localhost/policeMGMT/login11.php'>Login</a>";
    }
    mysqli_close($conn);
}

?>