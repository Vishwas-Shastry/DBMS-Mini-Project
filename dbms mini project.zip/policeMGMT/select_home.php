
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="dbms proj.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<title>Police Station Management System</title>
</head>
<body background = "POLICE_line.jpg"; background-size 100% 100%>
	<div class="banner">
		<div class="navbar">
			<img src = "http://localhost/policeMGMT/Bangalore_City_Police_Logo.png" class = "logo">
				<ul>
                <li><a href='http://localhost/policeMGMT/home_page.php#'>Home</a></li>
					<li><a href='http://localhost/policeMGMT/select_home.php'>View</a></li>
					<li><a href='http://localhost/policeMGMT/insert_home.php'>Add</a></li>
					<li><a href='http://localhost/policeMGMT/sp_home.php'>Optimize</a></li>
					<li><a href='http://localhost/policeMGMT/delete_dome.php'>Delete</a></li>
					<li><a href='http://localhost/policeMGMT/login11.php'>Logout</a></li>
				</ul>	
		</div>
		<div class="content">
			<form action="sel.php" method = "post">
				<button name = "A"><span>Number of Cases</span></button>
				<button name = "B"><span>Witness for open cases</span></button>
				<button name = "C"><span>Witnesses for case type</span></button>
				<button name = "D"><span>witness-criminal connection</span></button>
				<button name = "E"><span>Types of crimes</span></button>
				<button name = "F"><span>Number of officers</span></button>
				<button name = "G"><span>Officer - Case</span></button>
				<!-- <button type ="button"><span></span>E</button>
				<button type ="button"><span></span>F</button>
				<button type ="button"><span></span>G</button>  -->
			</form>	
		</div>
	</div>
</body>
</html>

