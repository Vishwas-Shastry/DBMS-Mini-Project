<?php
$servername="localhost";
$username="root";
$password="";
$database_name="policemgmt";

$conn=mysqli_connect($servername,$username,$password,$database_name);

if(!$conn)
{
    die("Connection Failed:" . mysqli_error());
}

if(isset($_POST['Delete']))
	{
		$a= $_POST['OfficerID'];
		
		$sql = "DELETE FROM police WHERE officer_id = '$a';";

        $result = mysqli_query($conn, $sql);
	
        if ($conn->query($sql) == TRUE)
		{
			echo 'Data deleted Successfully...!!';
		}
		else
		{
			echo "Error deleting record: " . mysqli_error($conn);
		}
	   header("refresh:1; url =  http://localhost/policeMGMT/home_page.php");
	}