<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officer details</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body background = "http://localhost/policeMGMT/diamondplate-background.jpg"; background-size 100% 100% >
    <center>
    <div class="wrapper_login">
        <div class="container">
            <div class="col-right">
                <div class="login-form">
                    <h2 style="color:white;">Insert values</h2>
                    <form action="server.php" method="post">
                        <p style="color:white;"> <label style="text-align: left;">Officer ID</label>&nbsp;<input type="text" name="OfficerID" placeholder="Officer id" required></p>
                        <p style="color:white;"> <label style="text-align: left;">Officer name</label>&nbsp;<input type="text" name="Officername" placeholder="officer Name" required> </p>
                        <p style="color:white;"> <label style="text-align: left;">Designation</label>&nbsp;<input type="text" name="Designation" placeholder="Designation" required></p>
                        <p style="color:white;"> <label style="text-align: left;">age</label>&nbsp;<input type="number" name="age" placeholder="age" required> </p>
                        <p style="color:white;"> <label style="text-align: left;">gender</label>&nbsp;<input type="text" name="gender" placeholder="gender" required></p>
                        <p style="color:white;"> <label style="text-align: left;">blood type</label>&nbsp;<input type="text" name="bloodtype" placeholder="blood type" required></p>
                        <p style="color:white;"> <label style="text-align: left;">Supervisor ID</label>&nbsp;<input type="text" name="superid" placeholder="Supervisor ID" > </p>
                        <p style="color:white;"> <label style="text-align: left;">address</label>&nbsp;<input type="text" name="address" placeholder="address" required> </p>
                        <button style="color: black;" type="submit" name="SignUp">submit</button>
                    </form>
                </div>
            </div>
        </div> 
    </div>
</center>
</body>
</html>