<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    
    border: 1px solid black;
   
}
</style>
</head>
<body>
    <center>


<?php
$servername="localhost";
$username="root";
$password="";
$database_name="policemgmt";

$conn = mysqli_connect($servername,$username,$password,$database_name);
//echo "Test";
if(!$conn)
{
    die("Connection Failed:" . mysqli_error());
}

if(isset($_POST['A']))
{
    // $l = $_POST['S_num'];
    // $sql = "SELECT * FROM employee where S_num='$l';";
    $sql1 = "SELECT p.officer_id, COUNT(*) as num_of_cases from police p join open_case oc on p.officer_id = oc.officer_id join closed_case cc on p.officer_id = cc.officer_id group by p.officer_id;";
    $result = $conn->query($sql1);
    if ($result->num_rows > 0)
    {
    // output data of each row
    echo "<table><tr><th>Officer ID</th><th>Number Of Cases</th></tr>";
    while($row = $result->fetch_assoc())
    {
        echo "<tr><td>" . $row["officer_id"]. "</td><td>" . $row["num_of_cases"]. "</td></tr>";
    }
    echo "</table>";
    } 
    else 
    { echo "0 results"; }
}

if(isset($_POST['B']))
{
    // $l = $_POST['S_num'];
    // $sql = "SELECT * FROM employee where S_num='$l';";
    $sql1 = "SELECT w.wit_aadhar,cc.case_id from witnesses w join closed_case cc ON w.case_id = cc.case_id;";
    $result = $conn->query($sql1);
    if ($result->num_rows > 0)
    {
    // output data of each row
    echo "<table><tr><th>wit_aadhar</th><th>case_id</th></tr>";
    while($row = $result->fetch_assoc())
    {
        echo "<tr><td>" . $row["wit_aadhar"]. "</td><td>" . $row["case_id"]. "</td></tr>";
    }
    echo "</table>";
    } 
    else 
    { echo "0 results"; }
}

if(isset($_POST['C']))
{
    // $l = $_POST['S_num'];
    // $sql = "SELECT * FROM employee where S_num='$l';";
    $sql1 = "select w.wit_name, c.case_type from witnesses w, open_case c where c.case_id = w.case_id;";
    $result = $conn->query($sql1);
    if ($result->num_rows > 0)
    {
    // output data of each row
    echo "<table><tr><h2>WITNESS NAME</h2><th></th><th>case_type</th></tr>";
    while($row = $result->fetch_assoc())
    {
        echo "<tr><td>" . $row["wit_name"]. "</td><td>" . $row["case_type"]. "</td></tr>";
    }
    echo "</table>";
    } 
    else 
    { echo "0 results"; }
}

if(isset($_POST['D']))
{
    // $l = $_POST['S_num'];
    // $sql = "SELECT * FROM employee where S_num='$l';";
    $sql1 = "SELECT * FROM wit_saw_criminal;";
    $result = $conn->query($sql1);
    if ($result->num_rows > 0)
    {
    // output data of each row
    echo "<table><tr><th>Witness name</th><th>Accused name</th></tr>";
    while($row = $result->fetch_assoc())
    {
        echo "<tr><td>" . $row["wit_name"]. "</td><td>" . $row["name"]. "</td></tr>";
    }
    echo "</table>";
    } 
    else 
    { echo "0 results"; }
}

if(isset($_POST['E']))
{
    // $l = $_POST['S_num'];
    // $sql = "SELECT * FROM employee where S_num='$l';";
    $sql1 = "SELECT case_id,case_type as crime_type from open_case group by case_type;";
    $result = $conn->query($sql1);
    if ($result->num_rows > 0)
    {
    // output data of each row
    echo "<table><tr><th>Case ID</th><th>Crime Type</th></tr>";
    while($row = $result->fetch_assoc())
    {
        echo "<tr><td>" . $row["case_id"]. "</td><td>" . $row["crime_type"]. "</td></tr>";
    }
    echo "</table>";
    } 
    else 
    { echo "0 results"; }
}

if(isset($_POST['F']))
{
    // $l = $_POST['S_num'];
    // $sql = "SELECT * FROM employee where S_num='$l';";
    $sql1 = "SELECT Number_of_police from noofpolice ;";
    $result = $conn->query($sql1);
    if ($result->num_rows > 0)
    {
    // output data of each row
    echo "<table><tr><th>Number of Police</th></tr>";
    while($row = $result->fetch_assoc())
    {
        echo "<tr><td>" . $row["Number_of_police"]. "</td></tr>";
    }
    echo "</table>";
    } 
    else 
    { echo "0 results"; }
}

if(isset($_POST['G']))
{
    // $l = $_POST['S_num'];
    // $sql = "SELECT * FROM employee where S_num='$l';";
    $sql1 = "SELECT p.officer_id,o.case_id FROM open_case o JOIN police p ON o.officer_id = p.officer_id;";
    $result = $conn->query($sql1);
    if ($result->num_rows > 0)
    {
    // output data of each row
    echo "<table><tr><th>Officer ID</th><th>Case Id</th></tr>";
    while($row = $result->fetch_assoc())
    {
        echo "<tr><td>" . $row["officer_id"]. "</td><td>" . $row["case_id"]. "</td></tr>";
    }
    echo "</table>";
    } 
    else 
    { echo "0 results"; }
}



$conn->close();
?>
</center>
</body>