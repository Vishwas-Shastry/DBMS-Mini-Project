
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="dbms proj.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<title>Police Case Management System</title>
</head>
<body background = "POLICE_line.jpg"; background-size 100% 100%> 
	<div class="banner">
		<div class="navbar">
			<img src = "http://localhost/policeMGMT/Bangalore_City_Police_Logo.png" class = "logo">
				<ul>
					<li><a href='http://localhost/policeMGMT/home_page.php#'>Home</a></li>
					<li><a href='http://localhost/policeMGMT/select_home.php'>View</a></li>
					<li><a href='http://localhost/policeMGMT/insert_home.php'>Add</a></li>
					<li><a href='http://localhost/policeMGMT/sp_home.php'>Optimize</a></li>
					<li><a href='http://localhost/policeMGMT/delete_dome.php'>Delete</a></li>
					<li><a href='http://localhost/policeMGMT/login11.php'>logout</a></li>
				</ul>	
		</div>
		<div class="content">
			<h1>DBMS Mini Project</h1><br>
			<p><h2>Topic: Police Station Management System</h2> <br>
				By: Sanmathi, Sudhanva<br><br>
				USN:1BG20CS093,1BG20CS109<br>
			</p>
		</div>
	</div>
</body>
</html>

