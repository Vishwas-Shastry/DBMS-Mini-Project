<?php
$servername="localhost";
$username="root";
$password="";
$database_name="policemgmt";

$conn = mysqli_connect($servername,$username,$password,$database_name);
//echo "Test";
if(!$conn)
{
    die("Connection Failed:" . mysqli_error());
}
if(isset($_POST['SignUp']))
{
        //echo "Inside";
        $a=$_POST['OfficerID'];
        $b=$_POST['Officername'];
        $c=$_POST['Designation'];
        $d=$_POST['age'];
        $e=$_POST['gender'];
        $f=$_POST['bloodtype'];
        $g=$_POST['address'];
        $h=$_POST['superid'];

        $sql_query="INSERT INTO police(officer_id,name,designation,age,gender,blood_type,address,super_id)
        values('$a','$b','$c','$d','$e','$f','$g','$h')";
        
        if (mysqli_query($conn, $sql_query)){
            header("Location: http://localhost/policeMGMT/home_page.php");
            //echo "New Customer added";
        }
        else {
            echo "Error: " . $sql . "" . mysqli_error($conn); 
        }
        mysqli_close($conn);   
 
}
?>