
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Verification</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
</head>
<body style="background-image: url('http://localhost/policeMGMT/POLICE.jpg'); background-size: cover;">  
    <div class="wrapper">
        <header style="color: whitesmoke;">Admin Verification</header>
        <form action="admin1.php" method = "post">
            <div class="field password">
                <div class="input-area">
                <input type="password" name = 'password' placeholder="Password"> 
                </div> 
                <div class="error error-txt">Password can't be blank</div>
            </div>
        <br>
        <br>
        <button type = "submit" name = "VerifyP" width="75%">
            <span style="position: relative; display: inline-flex;font-weight: bold;">
            Verify and insert Police info
            </span>
        </button>
        <button type = "submit" name = "VerifyC" width="75%">
            <span style="position: relative; display: inline-flex;font-weight: bold;">
            Verify and insert Open case
            </span>
        </button>
        <button type = "submit" name = "VerifyCO" width="75%">
            <span style="position: relative; display: inline-flex;font-weight: bold;">
            Verify and insert closed case
            </span>
        </button>
        <button type = "submit" name = "DeleteP" width="75%">
            <span style="position: relative; display: inline-flex;font-weight: bold;">
            Verify and delete Police info
            </span>
        </button>
    </form>
  </div>
</body>
</html>

