<?php
$servername="localhost";
$username="root";
$password="";
$database_name="policemgmt";

$conn = mysqli_connect($servername,$username,$password,$database_name);
//echo "Test";
if(!$conn)
{
    die("Connection Failed:" . mysqli_error());
}
if(isset($_POST['SignUp']))
{
        //echo "Inside";
        $a=$_POST['CaseID'];
        $b=$_POST['Casetype'];
        $c=$_POST['Datacollected'];
        $d=$_POST['CaseDate'];
        $e=$_POST['officerID'];

        $sql_query="INSERT INTO open_case(case_id	,case_type	,data_collected,	c_date	,officer_id	)
        values('$a','$b','$c','$d','$e')";
        
        if (mysqli_query($conn, $sql_query)){
            header("Location: http://localhost/policeMGMT/home_page.php");
            //echo "New Customer added";
        }
        else {
            echo "Error: " . $sql . "" . mysqli_error($conn); 
        }
        mysqli_close($conn);   
 
}
?>