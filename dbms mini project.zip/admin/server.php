<?php
$servername="localhost";
$username="root";
$password="";
$database_name="policemgmt";

$conn=mysqli_connect($servername,$username,$password,$database_name);
//echo "Test";
if(!$conn)
{
    die("Connection Failed:" . mysqli_error());
}
if(isset($_POST['SignUp']))
{
        $a=$_POST['OfficerID'];
        $b=$_POST['Officername'];
        $c=$_POST['Designation'];
        $d=$_POST['dob'];
        $e=$_POST['gender'];
        $f=$_POST['bloodtype'];
        $g=$_POST['superid'];
        $h=$_POST['address'];
        $i=$_POST['admpassword'];

        $s = " select * from admin_cred where admin_pwd = '$i';";

        $result = mysqli_query($conn, $s);

    $num= mysqli_num_rows($result);

    if ($num >0 ){
        
        $sql_query="INSERT INTO police values('$a','$b','$c','$d','$e','$f','$g','$h')";
        
        
    }

        
        if (mysqli_query($conn, $sql_query)){
            header("Location: http://localhost/ott/home.php");
            //echo "New Customer added";
        }
        else {
            echo "Error: " . $sql . "" . mysqli_error($conn); 
        }
        mysqli_close($conn);
}


?>