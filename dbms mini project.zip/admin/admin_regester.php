<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officer details</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body background = "http://localhost/policeMGMT/diamondplate-background.jpg"; background-size 100% 100% >
    <center>
    <div class="wrapper_login">
        <div class="container">
            <div class="col-left">
            </div>
            <div class="col-right">
                <div class="login-form">
                    <h2 style="color:white;">Insert values</h2>
                    <form action="server.php" method="post">
                        <p style="color:white;"> <label style="text-align: left;">Officer ID</label>&nbsp;<input type="text" name="OfficerID" placeholder="Officer id" required></p>
                        <p style="color:white;"> <label style="text-align: left;">Officer name<span></span></label> <input type="text" name="Officername" placeholder="officer Name" required> </p>
                        <p style="color:white;"> <label style="text-align: left;">Designation</label>&nbsp;<input type="text" name="Designation" placeholder="Designation" required></p>
                        <p style="color:white;"> <label style="text-align: left;">dob<span></span></label> <input type="date" name="dob" placeholder="dob" required> </p>
                        <p style="color:white;"> <label style="text-align: left;">gender</label>&nbsp;<input type="text" name="gender" placeholder="gender" required></p>
                        <p style="color:white;"> <label style="text-align: left;">blood type</label>&nbsp;<input type="text" name="bloodtype" placeholder="blood type" required></p>
                        <p style="color:white;"> <label style="text-align: left;">Supervisor ID<span></span></label> <input type="text" name="superid" placeholder="Supervisor ID" > </p>
                        <p style="color:white;"> <label style="text-align: left;">address<span></span></label> <input type="text" name="address" placeholder="address" required> </p>
                        <p style="color:white;"> <label>password<span></span></label> <input type="password" name="admpassword" placeholder="password" required> </p>
                        <button style="color: black;" type="submit" class = "btn" name="SignUp">signup</button>
                    </form>
                </div>
            </div>
        </div> 
    </div>
</center>
</body>
</html>